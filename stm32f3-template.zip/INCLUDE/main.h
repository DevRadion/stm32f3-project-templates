#ifndef __MAIN_H
#define __MAIN_H

#include "stm32f3xx.h"

#endif /* __MAIN_H */
