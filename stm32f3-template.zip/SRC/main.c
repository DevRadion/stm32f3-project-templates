#include "main.h"

int main(void) {
  while (1) {
  }
}
